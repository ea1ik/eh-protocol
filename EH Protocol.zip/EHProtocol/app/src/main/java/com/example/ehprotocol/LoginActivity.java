package com.example.ehprotocol;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static String username = "ea1ik";
    private static String password = "123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextView usernameText = (TextView) findViewById(R.id.userPlainText),
                passwordTxt = (TextView) findViewById(R.id.passwordPlainText);

        Button loginButton = (Button) findViewById(R.id.loginButton);

        loginButton.setOnClickListener(e -> {
            if(usernameText.getText().equals(username) && passwordTxt.getText().equals(password)){
                Intent intent = new Intent(getApplicationContext(), MainMenuActivity.class);
                startActivity(intent);
            }
            else{

            }
        });

    }
}
